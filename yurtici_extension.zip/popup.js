async function saveSettings(s) {
  await chrome.storage.local.set({ settings: s });
}
async function loadSettings() {
  const out = await chrome.storage.local.get(["settings"]);
  return out.settings || { code: "", interval: 15, target: "VARDI", tts: true, sound: true, stopOnTarget: true };
}
const qs = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async () => {
  const s = await loadSettings();
  qs("code").value = s.code || "";
  qs("interval").value = s.interval ?? 15;
  qs("target").value = s.target || "VARDI";
  qs("tts").checked = !!s.tts;
  qs("sound").checked = !!s.sound;
  qs("stopOnTarget").checked = !!s.stopOnTarget;

  qs("open").addEventListener("click", async () => {
    const code = (qs("code").value || "").trim();
    const interval = Math.max(5, parseInt(qs("interval").value || "15", 10));
    const target = qs("target").value;
    const tts = qs("tts").checked;
    const sound = qs("sound").checked;
    const stopOnTarget = qs("stopOnTarget").checked;

    if (!code) return alert("Gönderi kodu gir.");

    await saveSettings({ code, interval, target, tts, sound, stopOnTarget });

    const url = chrome.runtime.getURL("monitor.html");
    await chrome.tabs.create({ url });
    window.close();
  });
});
