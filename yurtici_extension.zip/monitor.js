let timer = null;
let lastKey = null;
let started = false;
let saidInitial = false;

function log(msg) {
  const el = document.getElementById("log");
  const ts = new Date().toLocaleTimeString();
  el.value += `[${ts}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}

async function getSettings() {
  const out = await chrome.storage.local.get(["settings"]);
  return out.settings || { code: "", interval: 15, target: "VARDI", tts: true, sound: true, stopOnTarget: true };
}

function setUI(id, text) { document.getElementById(id).textContent = text; }

function normTR(s) {
  s = (s || "").trim();
  return s
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/İ/g, "I")
    .replace(/ı/g, "I")
    .replace(/\s+/g, " ")
    .toUpperCase();
}

function classify(info) {
  if (info.notFound) return "NOT_FOUND";

  const step = Number.isFinite(info.progressStep) ? info.progressStep : null;
  if (step !== null) {
    if (step >= 4) return "TESLIM";
    if (step >= 3) return "VARDI";
    if (step >= 2) return "YOLDA";
  }

  const st = normTR(info.shipmentStatus || "");
  if (st.includes("TESLIM EDILDI") || st.includes("TESLİM EDİLDİ")) return "TESLIM";
  if (st.includes("VARIS BIRIMINDE") || st.includes("VARIŞ BİRİMİNDE")) return "VARDI";
  if (["TASIMA", "TAŞIMA", "TRANSFER", "SEVK", "YOLDA"].some(k => st.includes(k))) return "YOLDA";

  return "UNKNOWN";
}

function shouldStop(currentState, target) {
  if (target === "YOLDA") return false;
  if (target === "TESLIM") return currentState === "TESLIM";
  return currentState === "VARDI" || currentState === "TESLIM";
}

function pickGoogleTurkishVoice() {
  const voices = speechSynthesis.getVoices() || [];
  const v = voices.find(v =>
    /google/i.test(v.name) && /(tr|turk|türk)/i.test((v.lang || "") + " " + v.name)
  );
  return v || null;
}

function speakWord(word) {
  const u = new SpeechSynthesisUtterance(word);
  const v = pickGoogleTurkishVoice();
  if (v) u.voice = v;
  u.lang = "tr-TR";
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}

function playSound(enabled) {
  if (!enabled) return;
  const url = chrome.runtime.getURL("ok.mp3");
  const audio = new Audio(url);
  audio.volume = 1.0;
  audio.play().catch(() => {
    log("Ses çalınamadı. ok.mp3 var mı? (Eklenti klasörüne koyup yeniden yükle)");
  });
}

async function fetchInfo(code) {
  const resp = await chrome.runtime.sendMessage({ type: "fetch_dom", code });
  if (resp && resp.error) throw new Error(resp.error);
  return resp;
}

function initialSpeakIfNeeded(state, ttsEnabled) {
  if (!ttsEnabled || saidInitial) return;
  if (state === "TESLIM") speakWord("teslim");
  else if (state === "VARDI") speakWord("vardı");
  else if (state === "YOLDA") speakWord("yolda");
  saidInitial = true;
}

async function tick() {
  const s = await getSettings();
  if (!s.code) return;

  setUI("settingsLine", `Kod: ${s.code} | Aralık: ${s.interval}s | Hedef: ${s.target} | TTS: ${s.tts ? "Açık" : "Kapalı"} | Ses: ${s.sound ? "Açık" : "Kapalı"} | Durdur: ${s.stopOnTarget ? "Açık" : "Kapalı"}`);

  try {
    const info = await fetchInfo(s.code);

    const state = classify(info);
    setUI("state", state);
    setUI("statusText", `Durum: ${info.shipmentStatus || "—"}`);
    setUI("route", `Güzergâh: ${(info.departureCityCounty||"—")} → ${(info.deliveryCityCounty||"—")}`);
    setUI("units", `Teslim birimi: ${info.deliveryUnit || "—"} | Son işlem: ${info.lastProcess || "—"}`);
    setUI("lastCheck", `Son kontrol: ${new Date().toLocaleTimeString()}`);
    setUI("raw", `shipmentStatus: ${info.shipmentStatus || "—"}`);
    setUI("step", `step: ${Number.isFinite(info.progressStep) ? info.progressStep : "—"}`);

    if (state === "NOT_FOUND") {
      log("❌ KARGO BULUNAMADI (NOT_FOUND). Durduruldu.");
      stop();
      return;
    }

    const key = `${state}|${info.shipmentStatus||""}|${info.progressStep||""}|${info.lastProcess||""}`;
    if (lastKey === null) {
      lastKey = key;
      log(`İlk durum: ${state} (${info.shipmentStatus || ""}) step=${Number.isFinite(info.progressStep)?info.progressStep:"—"}`);
      initialSpeakIfNeeded(state, !!s.tts);

      if (s.stopOnTarget && shouldStop(state, s.target)) {
        log(`Hedef zaten sağlandı (${s.target}). Durduruldu.`);
        stop();
      }
    } else if (key !== lastKey) {
      lastKey = key;
      log(`Değişti: ${state} (${info.shipmentStatus || ""}) step=${Number.isFinite(info.progressStep)?info.progressStep:"—"}`);

      playSound(!!s.sound);

      if (s.tts) {
        if (state === "VARDI") speakWord("vardı");
        if (state === "TESLIM") speakWord("teslim");
      }

      if (s.stopOnTarget && shouldStop(state, s.target)) {
        log(`Hedefe ulaştı (${s.target}). Durduruldu.`);
        stop();
      }
    } else {
      log(`Aynı: ${state} (${info.shipmentStatus || ""}) step=${Number.isFinite(info.progressStep)?info.progressStep:"—"}`);
    }
  } catch (e) {
    log("Hata: " + (e && e.message ? e.message : String(e)));
  }
}

async function start() {
  if (started) return;
  started = true;
  log("Başladı.");
  await tick();
  const s = await getSettings();
  const ms = Math.max(5000, (parseInt(s.interval || 15, 10) * 1000));
  if (timer) clearInterval(timer);
  timer = setInterval(tick, ms);
}

function stop() {
  started = false;
  if (timer) clearInterval(timer);
  timer = null;
  log("Durduruldu.");
}

document.addEventListener("DOMContentLoaded", async () => {
  speechSynthesis.onvoiceschanged = () => {};

  document.getElementById("start").addEventListener("click", start);
  document.getElementById("stop").addEventListener("click", stop);

  document.getElementById("testTTS").addEventListener("click", () => {
    speakWord("yolda");
    setTimeout(() => speakWord("vardı"), 900);
    setTimeout(() => speakWord("teslim"), 1800);
  });

  document.getElementById("testSound").addEventListener("click", async () => {
    const s = await getSettings();
    playSound(!!s.sound);
  });

  start();
});
