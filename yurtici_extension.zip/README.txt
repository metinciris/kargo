Yurtiçi Takip Chrome Extension v1.1.1

Fix: Eklenti sürekli yeni Yurtiçi sekmesi açıyordu.
Sebep: Manifest V3 service worker uykuya gidince global değişkenler sıfırlanır ve hiddenTabId unutulur.

Bu sürüm:
- hiddenTabId'yi chrome.storage.local içine yazar (persist).
- Uyandıktan sonra aynı sekmeyi yeniden kullanır.
- Ayrıca 'gonderi-sorgula' URL'li fazla sekmeleri otomatik kapatır (birikme engellenir).
- DOM içinde data-step (2/3/4) veya yıldız olmayan shipmentStatus gelene kadar bekler.

Not:
- Arka planda 1 adet pinned Yurtiçi sekmesi görünebilir (tek tane). Birikmez.
