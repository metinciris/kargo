const TRACK_URL_PREFIX = "https://www.yurticikargo.com/tr/online-servisler/gonderi-sorgula?code=";
const STORAGE_KEY = "yk_hidden_tab_id";

let hiddenTabId = null;
let hiddenTabBusy = false;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function loadHiddenTabId() {
  const out = await chrome.storage.local.get([STORAGE_KEY]);
  const id = out[STORAGE_KEY];
  if (typeof id === "number") hiddenTabId = id;
}

async function saveHiddenTabId(id) {
  hiddenTabId = id;
  await chrome.storage.local.set({ [STORAGE_KEY]: id });
}

async function clearHiddenTabId() {
  hiddenTabId = null;
  await chrome.storage.local.remove([STORAGE_KEY]);
}

function ensureUrl(code) {
  return TRACK_URL_PREFIX + encodeURIComponent(String(code || "").trim()) + "&_=" + Date.now();
}

async function cleanupExtraYkTabs(keepId) {
  try {
    const tabs = await chrome.tabs.query({ url: TRACK_URL_PREFIX + "*" });
    for (const t of tabs) {
      if (t.id !== keepId) {
        try { await chrome.tabs.remove(t.id); } catch(e) {}
      }
    }
  } catch (e) {}
}

async function ensureHiddenTab(url) {
  if (hiddenTabId === null) {
    await loadHiddenTabId();
  }

  if (hiddenTabId !== null) {
    try {
      await chrome.tabs.get(hiddenTabId);
      await chrome.tabs.update(hiddenTabId, { url, active: false });
      await cleanupExtraYkTabs(hiddenTabId);
      return hiddenTabId;
    } catch (e) {
      await clearHiddenTabId();
    }
  }

  const tab = await chrome.tabs.create({ url, active: false, pinned: true });
  await saveHiddenTabId(tab.id);
  await cleanupExtraYkTabs(tab.id);
  return tab.id;
}

async function waitTabComplete(tabId, timeoutMs = 15000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === "complete") return;
    await sleep(200);
  }
}

async function readDomFromTab(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: async () => {
      const sleep = (ms) => new Promise(r => setTimeout(r, ms));
      const norm = (s) => (s || "").toString().trim();

      const isStars = (s) => {
        s = norm(s);
        if (!s) return true;
        for (const ch of s) if (ch !== "*") return false;
        return true;
      };

      const getStep = () => {
        const el = document.getElementById("four-pack");
        const v = el ? el.getAttribute("data-step") : "";
        const n = parseInt((v || "").toString().trim(), 10);
        return Number.isFinite(n) ? n : null;
      };

      const getStatus = () => {
        const el = document.getElementById("shipmentStatus");
        return el ? norm(el.innerText) : "";
      };

      const getByIdText = (id) => {
        const el = document.getElementById(id);
        return el ? norm(el.innerText) : "";
      };

      const notFound = () => {
        const t = (document.body ? document.body.innerText : "") || "";
        return /kargo bulunamad/i.test(t) || /bir kargo bulunamad/i.test(t) || /gönderi kodu.*bulunamad/i.test(t);
      };

      const deadline = Date.now() + 12000;

      while (Date.now() < deadline) {
        if (notFound()) break;
        const step = getStep();
        const status = getStatus();
        const stepOk = step === 2 || step === 3 || step === 4;
        const statusOk = status && !isStars(status);
        if (stepOk || statusOk) break;
        await sleep(250);
      }

      return {
        shipmentStatus: getStatus(),
        lastProcess: getByIdText("LastProcessCityCountry"),
        deliveryUnit: getByIdText("deliveryUnitName"),
        departureCityCounty: getByIdText("departureCityCounty"),
        deliveryCityCounty: getByIdText("deliveryCityCounty"),
        progressStep: getStep(),
        notFound: notFound(),
      };
    }
  });
  return result;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg?.type !== "fetch_dom") {
        sendResponse({ error: "unknown message" });
        return;
      }
      const code = String(msg.code || "").trim();
      if (!code) {
        sendResponse({ error: "code missing" });
        return;
      }

      while (hiddenTabBusy) await sleep(100);
      hiddenTabBusy = true;

      const url = ensureUrl(code);
      const tabId = await ensureHiddenTab(url);
      await waitTabComplete(tabId, 15000);

      const data = await readDomFromTab(tabId);

      hiddenTabBusy = false;
      sendResponse(data);
    } catch (e) {
      hiddenTabBusy = false;
      sendResponse({ error: (e && e.message) ? e.message : String(e) });
    }
  })();
  return true;
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === hiddenTabId) {
    clearHiddenTabId();
  }
});
